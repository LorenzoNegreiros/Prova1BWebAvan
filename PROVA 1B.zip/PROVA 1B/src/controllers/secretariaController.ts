import { PrismaClient } from '@prisma/client';

const prisma = new PrismaClient();

// Criar uma nova secretaria
export const criarSecretaria = async (req: { body: { nome: any; RG: any; }; }, res: { status: (arg0: number) => { (): any; new(): any; json: { (arg0: { error: string; }): void; new(): any; }; }; }) => {
  try {
    const { nome, RG } = req.body;
    const secretaria = await prisma.secretaria.create({
      data: {
        nome,
        RG,
      },
    });
    res.status(201).json(secretaria);
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: 'Erro ao criar a secretaria.' });
  }
};

// Listar todas as secretarias
export const listarSecretarias = async (req: any, res: { status: (arg0: number) => { (): any; new(): any; json: { (arg0: { error: string; }): void; new(): any; }; }; }) => {
  try {
    const secretarias = await prisma.secretaria.findMany();
    res.status(200).json(secretarias);
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: 'Erro ao listar as secretarias.' });
  }
};

// Atualizar uma secretaria existente
export const atualizarSecretaria = async (req: { params: { id: any; }; body: { nome: any; RG: any; }; }, res: { status: (arg0: number) => { (): any; new(): any; json: { (arg0: { error: string; }): void; new(): any; }; }; }) => {
  const { id } = req.params;
  const { nome, RG } = req.body;

  try {
    const secretaria = await prisma.secretaria.update({
      where: { id: Number(id) },
      data: {
        nome,
        RG,
      },
    });
    res.status(200).json(secretaria);
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: 'Erro ao atualizar a secretaria.' });
  }
};

// Deletar uma secretaria
export const deletarSecretaria = async (req: { params: { id: any; }; }, res: { status: (arg0: number) => { (): any; new(): any; end: { (): void; new(): any; }; json: { (arg0: { error: string; }): void; new(): any; }; }; }) => {
  const { id } = req.params;

  try {
    await prisma.secretaria.delete({
      where: { id: Number(id) },
    });
    res.status(204).end();
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: 'Erro ao deletar a secretaria.' });
  }
};
