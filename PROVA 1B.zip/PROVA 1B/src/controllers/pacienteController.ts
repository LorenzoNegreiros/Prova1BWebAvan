import { PrismaClient } from '@prisma/client';

const prisma = new PrismaClient();

// Criar um novo paciente
export const criarPaciente = async (req: { body: { nomePcnte: any; senha: any; usuario: any; }; }, res: { status: (arg0: number) => { (): any; new(): any; json: { (arg0: { error: string; }): void; new(): any; }; }; }) => {
  try {
    const { nomePcnte, senha, usuario } = req.body;
    const paciente = await prisma.paciente.create({
      data: {
        nomePcnte,
        senha,
        usuario,
      },
    });
    res.status(201).json(paciente);
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: 'Erro ao criar o paciente.' });
  }
};

// Listar todos os pacientes
export const listarPacientes = async (_req: any, res: { status: (arg0: number) => { (): any; new(): any; json: { (arg0: { error: string; }): void; new(): any; }; }; }) => {
  try {
    const pacientes = await prisma.paciente.findMany();
    res.status(200).json(pacientes);
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: 'Erro ao listar os pacientes.' });
  }
};

// Atualizar um paciente existente
export const atualizarPaciente = async (req: { params: { id: any; }; body: { nomePcnte: any; senha: any; usuario: any; }; }, res: { status: (arg0: number) => { (): any; new(): any; json: { (arg0: { error: string; }): void; new(): any; }; }; }) => {
  const { id } = req.params;
  const { nomePcnte, senha, usuario } = req.body;

  try {
    const paciente = await prisma.paciente.update({
      where: { id: Number(id) },
      data: {
        nomePcnte,
        senha,
        usuario,
      },
    });
    res.status(200).json(paciente);
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: 'Erro ao atualizar o paciente.' });
  }
};

// Deletar um paciente
export const deletarPaciente = async (req: { params: { id: any; }; }, res: { status: (arg0: number) => { (): any; new(): any; end: { (): void; new(): any; }; json: { (arg0: { error: string; }): void; new(): any; }; }; }) => {
  const { id } = req.params;

  try {
    await prisma.paciente.delete({
      where: { id: Number(id) },
    });
    res.status(204).end();
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: 'Erro ao deletar o paciente.' });
  }
};
