import { PrismaClient } from '@prisma/client';

const prisma = new PrismaClient();

// Criar um novo item de agenda
export const criarItemAgenda = async (req: { body: { data: any; nomePcnt: any; }; }, res: { status: (arg0: number) => { (): any; new(): any; json: { (arg0: { error: string; }): void; new(): any; }; }; }) => {
  try {
    const { data, nomePcnt } = req.body;
    const itemAgenda = await prisma.agenda.create({
      data: {
        data,
        nomePcnt,
      },
    });
    res.status(201).json(itemAgenda);
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: 'Erro ao criar o item da agenda.' });
  }
};

// Listar todos os itens da agenda
export const listarItensAgenda = async (req: any, res: { status: (arg0: number) => { (): any; new(): any; json: { (arg0: { error: string; }): void; new(): any; }; }; }) => {
  try {
    const itensAgenda = await prisma.agenda.findMany();
    res.status(200).json(itensAgenda);
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: 'Erro ao listar os itens da agenda.' });
  }
};

// Atualizar um item da agenda existente
export const atualizarItemAgenda = async (req: { params: { id: any; }; body: { data: any; nomePcnt: any; }; }, res: { status: (arg0: number) => { (): any; new(): any; json: { (arg0: { error: string; }): void; new(): any; }; }; }) => {
  const { id } = req.params;
  const { data, nomePcnt } = req.body;

  try {
    const itemAgenda = await prisma.agenda.update({
      where: { id: Number(id) },
      data: {
        data,
        nomePcnt,
      },
    });
    res.status(200).json(itemAgenda);
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: 'Erro ao atualizar o item da agenda.' });
  }
};

// Deletar um item da agenda
export const deletarItemAgenda = async (req: { params: { id: any; }; }, res: { status: (arg0: number) => { (): any; new(): any; end: { (): void; new(): any; }; json: { (arg0: { error: string; }): void; new(): any; }; }; }) => {
  const { id } = req.params;

  try {
    await prisma.agenda.delete({
      where: { id: Number(id) },
    });
    res.status(204).end();
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: 'Erro ao deletar o item da agenda.' });
  }
};
