import { PrismaClient } from '@prisma/client';

const prisma = new PrismaClient();

// Criar uma nova consulta
export const criarConsulta = async (req: { body: { data: any; nomePcnte: any; nomeDents: any; }; }, res: { status: (arg0: number) => { (): any; new(): any; json: { (arg0: { error: string; }): void; new(): any; }; }; }) => {
  try {
    const { data, nomePcnte, nomeDents } = req.body;
    const consulta = await prisma.consulta.create({
      data: {
        data,
        nomePcnte,
        nomeDents,
      },
    });
    res.status(201).json(consulta);
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: 'Erro ao criar a consulta.' });
  }
};

// Listar todas as consultas
export const listarConsultas = async (req: any, res: { status: (arg0: number) => { (): any; new(): any; json: { (arg0: { error: string; }): void; new(): any; }; }; }) => {
  try {
    const consultas = await prisma.consulta.findMany();
    res.status(200).json(consultas);
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: 'Erro ao listar as consultas.' });
  }
};

// Atualizar uma consulta existente
export const atualizarConsulta = async (req: { params: { id: any; }; body: { data: any; nomePcnte: any; nomeDents: any; }; }, res: { status: (arg0: number) => { (): any; new(): any; json: { (arg0: { error: string; }): void; new(): any; }; }; }) => {
  const { id } = req.params;
  const { data, nomePcnte, nomeDents } = req.body;

  try {
    const consulta = await prisma.consulta.update({
      where: { id: Number(id) },
      data: {
        data,
        nomePcnte,
        nomeDents,
      },
    });
    res.status(200).json(consulta);
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: 'Erro ao atualizar a consulta.' });
  }
};

// Deletar uma consulta
export const deletarConsulta = async (req: { params: { id: any; }; }, res: { status: (arg0: number) => { (): any; new(): any; end: { (): void; new(): any; }; json: { (arg0: { error: string; }): void; new(): any; }; }; }) => {
  const { id } = req.params;

  try {
    await prisma.consulta.delete({
      where: { id: Number(id) },
    });
    res.status(204).end();
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: 'Erro ao deletar a consulta.' });
  }
};
