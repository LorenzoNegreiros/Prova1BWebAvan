import express from 'express';
import bodyParser from 'body-parser';

// Importe seus controladores
import {
  criarPaciente,
  listarPacientes,
  atualizarPaciente,
  deletarPaciente,
} from './controllers/pacienteController';

import {
  criarConsulta,
  listarConsultas,
  atualizarConsulta,
  deletarConsulta,
} from './controllers/consultaController';

import {
  criarItemAgenda,
  listarItensAgenda,
  atualizarItemAgenda,
  deletarItemAgenda,
} from './controllers/agendaController';

import {
  criarSecretaria,
  listarSecretarias,
  atualizarSecretaria,
  deletarSecretaria,
} from './controllers/secretariaController';

const app = express();
const PORT = process.env.PORT || 3000;

app.use(bodyParser.json());

// Rotas para Paciente
app.post('/pacientes', criarPaciente);
app.get('/pacientes', listarPacientes);
app.put('/pacientes/:id', atualizarPaciente);
app.delete('/pacientes/:id', deletarPaciente);

// Rotas para Consulta
app.post('/consultas', criarConsulta);
app.get('/consultas', listarConsultas);
app.put('/consultas/:id', atualizarConsulta);
app.delete('/consultas/:id', deletarConsulta);

// Rotas para Agenda
app.post('/agenda', criarItemAgenda);
app.get('/agenda', listarItensAgenda);
app.put('/agenda/:id', atualizarItemAgenda);
app.delete('/agenda/:id', deletarItemAgenda);

// Rotas para Secretaria
app.post('/secretarias', criarSecretaria);
app.get('/secretarias', listarSecretarias);
app.put('/secretarias/:id', atualizarSecretaria);
app.delete('/secretarias/:id', deletarSecretaria);

app.listen(PORT, () => {
  console.log(`Servidor está rodando na porta ${PORT}`);
});
